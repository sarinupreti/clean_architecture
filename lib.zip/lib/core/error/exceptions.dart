class ServerException implements Exception {}

class SocketException implements Exception {}

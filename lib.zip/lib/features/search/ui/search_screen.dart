import 'package:clean_architecture_example/features/search/model/search_view_model.dart';
import 'package:clean_framework/clean_framework.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class SearchScreen extends Screen {
  final SearchViewModal viewModel;
  void Function(String artist, String songName) onTapSubmit;

  TextEditingController _songController = TextEditingController();

  SearchScreen({
    this.viewModel,
    this.onTapSubmit,
  });

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        title: Text("Search Songs"),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Form(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              SizedBox(height: media.width * .01),
              _textFormField(
                  Key('title_key'), 'Artist - Song Title', TextInputType.text),
              SizedBox(height: media.width * .02),
              RaisedButton(
                key: Key('login_button_key'),
                color: Colors.red,
                onPressed: () {
                  final name = _songController.text.split("-");
                  final artistName = name.first.trim();
                  final titleName = name.last.trim();

                  onTapSubmit(artistName, titleName);
                },
                child: Text('Search', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _textFormField(Key key, String hintText, TextInputType textInputType) {
    return TextFormField(
      key: key,
      keyboardType: textInputType,
      controller: _songController,
      textInputAction: TextInputAction.next,
      decoration: InputDecoration(
        hintText: hintText,
        contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
      ),
      onChanged: (value) {},
    );
  }
}

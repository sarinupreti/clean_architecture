import 'package:clean_architecture_example/features/search/bloc/search_bloc.dart';
import 'package:clean_architecture_example/features/search/model/search_view_model.dart';
import 'package:clean_architecture_example/features/search/ui/search_screen.dart';
import 'package:clean_framework/clean_framework.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

class SearchPresenter
    extends Presenter<SearchBloc, SearchViewModal, SearchScreen> {
  @override
  SearchScreen buildScreen(
      BuildContext context, SearchBloc bloc, SearchViewModal viewModel) {
    SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
      if (viewModel.serviceStatus == ServiceStatus.success) {
        return;
      } else if (viewModel.serviceStatus == ServiceStatus.fail) {
        _showErrorDialog(context);
      } else if (viewModel.serviceStatus == ServiceStatus.unknown) {
        _showInvalidDataDialog(context);
      }
    });
    return SearchScreen(
      viewModel: viewModel,
      onTapSubmit: (String artist, String title) =>
          _onTapSubmit(bloc, artist, title),
    );
  }

  void _onChangedArtistName(SearchBloc bloc, String artistName) {
    bloc.artistPipe.send(artistName);
  }

  void _onChangeSongTitle(SearchBloc bloc, String songTitle) {
    bloc.titlePipe.send(songTitle);
  }

  @override
  Stream<SearchViewModal> getViewModelStream(SearchBloc bloc) {
    return bloc.searchViewModelPipe.receive;
  }

  @override
  Widget buildLoadingScreen(BuildContext context) {
    return Center(
      child: CircularProgressIndicator(),
    );
  }

  // void _navigateToHubScreen(BuildContext context) {
  //   CFRouterScope.of(context).push(CustomRouter.resultRoute);
  // }

  // Add back in when login is added
  void _onTapSubmit(SearchBloc bloc, String artist, String song) {
    _onChangedArtistName(bloc, artist);
    _onChangeSongTitle(bloc, song);
    bloc.submitPipe.launch();
  }

  void _showErrorDialog(BuildContext context) {
    // showDialog(
    //   context: context,
    //   builder: (_) => AlertDialog(
    //     title: Text('Error'),
    //     content: Text('Submit Failed'),
    //     actions: <Widget>[
    //       FlatButton(
    //         onPressed: () {
    //           CFRouterScope.of(context).pop();
    //         },
    //         child: Text('OK'),
    //       )
    //     ],
    //   ),
    // );
  }

  void _showInvalidDataDialog(BuildContext context) {
    // showDialog(
    //   context: context,
    //   builder: (_) => AlertDialog(
    //     title: Text('Invalid'),
    //     content: Text('Data entered is incorrect.'),
    //     actions: <Widget>[
    //       FlatButton(
    //         onPressed: () {
    //           CFRouterScope.of(context).pop();
    //         },
    //         child: Text('OK'),
    //       )
    //     ],
    //   ),
    // );
  }
}
